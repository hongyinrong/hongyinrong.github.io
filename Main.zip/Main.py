import random

rating_n, user_n, book_n = map(int, input().split("\t"))
data = [[-1 for i in range(book_n)] for j in range(user_n)]
for i in range(rating_n):
    user_id, book_id, rating = map(int, input().split("\t"))
    data[user_id][book_id] = rating


n, m, k = user_n, book_n, 6
a,b=0.015,0.015
P,Q,R,D = [[a for i in range(k)] for j in range(n)], [[b for i in range(k)] for j in range(m)], [[0 for i in range(m)] for j in range(n)],data
E = [[0 for i in range(m)] for j in range(n)]
temp_P,temp_Q=[],[]
alpha, beta, error = 1E-4, 0.02, 4E-8


def Transpose(matrix: list) -> list:
    r, c = len(matrix), len(matrix[0])
    result = [[0 for i in range(r)] for j in range(c)]
    for i in range(r):
        for j in range(c):
            result[j][i] = matrix[i][j]
    return result

def MatrixMultiply(A: list, B: list) -> list:
    result = [[0 for i in range(m)] for j in range(n)]
    for i in range(n):
        for j in range(m):
            R[i][j]=0
            for s in range(k):
                R[i][j] += A[i][s] * B[s][j]
    return result

def getError()->float:
    r, c = len(R), len(R[0])
    result = 0
    for i in range(r):
        for j in range(c):
            result += R[i][j] * R[i][j]
    return result

def getTop10(l: list, u: int) -> list:
    r = l[:]
    id = [i for i in range(len(l))]
    for i in range(len(l)):
        for j in range(i + 1, len(l)):
            if r[j] > r[i]:
                r[i], r[j] = r[j], r[i]
                id[i], id[j] = id[j], id[i]
    result = []

    for i in range(len(l)):

        if data[u][id[i]] <= 0:

            #
            if len(result) < 10:
                result.append(id[i])
            else:
                for j in range(i, len(l)):
            #
                    if r[j] == r[9]:
                        result.append(id[i])
                    else:
                        break
                break
    return result



MatrixMultiply(P, Transpose(Q))

def updateE():
    for i in range(n):
        for j in range(m):
            if D[i][j] > 0:
                E[i][j] = D[i][j] - R[i][j]
            else:
                D[i][j] = 0

updateE()
def update():
    temp_P,temp_Q=P,Q
    def updateP(i: int,j:int, s: int):
        P[i][s] = temp_P[i][s] - alpha * (2 * E[i][j] * temp_Q[j][s] - beta * temp_P[i][s])

    def updateQ(i:int,j: int, s: int):
        Q[j][s] = temp_Q[j][s] - alpha * (2 * E[i][j] * temp_P[i][s] - beta * temp_Q[j][s])


    for i in range(n):
        for j in range(m):
            if D[i][j] > 0:
                for s in range(k):
                    updateP(i,j, s)
                    updateQ(i,j, s)
    MatrixMultiply(P, Transpose(Q))
    updateE()








count=0;
while 1:
    update()
    a=getError()
    if  a< error:

        for i in range(n):
            continue
            if i<user_n-1:
               print("\t".join(list(map(str, getTop10(R[i], i)))))
            else:
                print("\t".join(list(map(str, getTop10(R[i], i)))),end="")
        quit(0)
        break

    count+=1
    #print(count,a)
    #continue


    if count==10:
        for i in range(n):
            # continue
            if i < user_n - 1:
                print("\t".join(list(map(str, getTop10(R[i], i)))))
            else:
                print("\t".join(list(map(str, getTop10(R[i], i)))), end="")
        quit(0)
        break















